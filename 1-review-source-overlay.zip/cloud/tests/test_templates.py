import json,re,unittest
from pathlib import Path
class TemplateTests(unittest.TestCase):
 def test_presets_match_android(self):
  root=Path(__file__).parents[2];rows=json.loads((root/'cloud/alarm-templates.json').read_text())
  self.assertEqual(rows,json.loads((root/'scripts/alarm-templates.json').read_text()))
  source=(root/'app/src/main/java/com/sysadmindoc/alarmclock/ui/templates/AlarmTemplate.kt').read_text()
  parts=source.split('AlarmTemplate(')[2:]
  for row in rows:
   part=next(p for p in parts if 'key = "'+row['key']+'"' in p)
   for key in ['hour','minute']:
    self.assertEqual(row['payload'][key],int(re.search(key+r' = (\d+)',part).group(1)))
   for key,default in [('gradualVolumeSeconds',60),('vibrationIntensity',2),('snoozeDurationMinutes',10)]:
    match=re.search(key+r' = (\d+)',part);self.assertEqual(row['payload'][key],int(match.group(1)) if match else default)
   match=re.search('challengeType = "([A-Z_]+)"',part);self.assertEqual(row['payload']['challengeType'],match.group(1) if match else 'NONE')
