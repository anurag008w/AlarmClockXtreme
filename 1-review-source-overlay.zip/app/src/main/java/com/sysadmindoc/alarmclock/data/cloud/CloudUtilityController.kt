package com.sysadmindoc.alarmclock.data.cloud

import android.content.Context
import android.os.SystemClock
import com.sysadmindoc.alarmclock.ui.timer.*

/** A phone owns ringing. Cloud countdowns are displays, never alarm deadlines. */
internal class CloudUtilityController(private val context: Context) {
    private val store = TimerStore(context)
    private val journal = context.getSharedPreferences("cloud_utility_journal", Context.MODE_PRIVATE)

    fun apply(command: CloudUtilityCommand): Pair<String, String> = synchronized(LOCK) {
        val prior = journal.getString(command.commandId, null)
        if (prior != null) {
            if (prior.startsWith("applied:") || prior.startsWith("rejected:"))
                return@synchronized prior.substringBefore(":") to prior.substringAfter(":")
            return@synchronized "rejected" to "interrupted_check_phone"
        }
        // Durable at-most-once claim before native effects. If the process dies
        // in between, reject redelivery instead of ringing a duplicate timer.
        check(journal.edit().putString(command.commandId, "claimed").commit())
        if (command.kind != "timer") return@synchronized "rejected" to "stopwatch_not_supported_yet"
        val now = SystemClock.elapsedRealtime()
        val result = runCatching {
            if (command.action == "start") {
                val seconds = (command.payload["seconds"] as? Number)?.toLong() ?: error("invalid_seconds")
                val record = store.startOrReuse(seconds, command.payload["label"] as? String ?: "", now).record
                TimerAlarmScheduler.schedule(context, record.id, record.endElapsedRealtime)
                TimerNotifications.postRunning(context, record)
                "timerId=${record.id}"
            } else {
                val id = (command.payload["timerId"] as? Number)?.toInt() ?: error("invalid_timer_id")
                val record = store.loadRecords(now).firstOrNull { it.id == id } ?: error("timer_not_found")
                when (command.action) {
                    "pause" -> {
                        require(record.state == TimerState.RUNNING) { "timer_not_running" }
                        store.upsert(record.copy(state=TimerState.PAUSED, endElapsedRealtime=0))
                        TimerAlarmScheduler.cancel(context, id);TimerNotifications.cancelTimer(context,id)
                    }
                    "resume" -> {
                        require(record.state == TimerState.PAUSED && record.remainingMillis > 0) { "timer_not_paused" }
                        val resumed = record.copy(state=TimerState.RUNNING,endElapsedRealtime=now+record.remainingMillis)
                        store.upsert(resumed);TimerAlarmScheduler.schedule(context,id,resumed.endElapsedRealtime)
                        TimerNotifications.postRunning(context,resumed)
                    }
                    "stop" -> {
                        store.remove(id);TimerAlarmScheduler.cancel(context,id)
                        TimerAlarmService.dismiss(context,id);TimerNotifications.cancelTimer(context,id)
                    }
                    else -> error("invalid_timer_action")
                }
                "timerId=$id"
            }
        }
        val status = if (result.isSuccess) "applied" else "rejected"
        val message = result.getOrElse { it.message ?: "native_action_failed" }
        journal.edit().putString(command.commandId, "$status:$message").commit()
        status to message
    }
    companion object { private val LOCK = Any() }
}
