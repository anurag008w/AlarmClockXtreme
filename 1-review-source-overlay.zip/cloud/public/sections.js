let newsFeeds=[];
async function loadNewsFeeds() {
 const data=await api('/api/news/feeds');newsFeeds=data.feeds;
 const match=newsFeeds.find(feed=>feed.url===phoneSettings.newsFeedUrl);
 $('newsFeed').innerHTML=newsFeeds.map(feed=>`<option value="${escapeAttr(feed.id)}">${escapeHtml(feed.label)}</option>`).join('');
 $('newsFeed').value=match?.id||'bbc';
 $('newsStatus').textContent=match ? 'Saved phone feed selected.' : 'Phone has a custom or unsynced feed. BBC is selected for reading only, not saved.';
}
async function refreshNews() {
 const button=$('newsRefresh');button.disabled=true;
 try {
  if(!newsFeeds.length)await loadNewsFeeds();
  const data=await api('/api/news?feed='+encodeURIComponent($('newsFeed').value));
  $('newsStatus').textContent=`${data.stale?'Cached news, refresh failed.':'Feed loaded.'} Fetched ${new Date(data.fetchedAtMillis).toLocaleString()}`;
  $('newsList').innerHTML=data.items.length ? data.items.map(item=>`<article class="card"><h3><a href="${escapeAttr(item.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(item.title)}</a></h3><p>${escapeHtml(item.summary)}</p><small class="muted">${escapeHtml(item.published)}</small></article>`).join('') : '<p>No feed entries.</p>';
 } catch(error){$('newsStatus').textContent='Could not refresh: '+error.message+'. Any previous entries below are unchanged.';}
 finally{button.disabled=false;}
}
$('newsRefresh').onclick=refreshNews;
$('newsSave').onclick=async()=>{
 if(!phoneSettingsVersion||phoneSettingsDirty){$('newsStatus').textContent='Sync an updated phone and save or reload existing settings first.';return;}
 const feed=newsFeeds.find(feed=>feed.id===$('newsFeed').value);if(!feed)return;
 phoneSettings.newsFeedUrl=feed.url;phoneSettingsDirty=true;await savePhoneSettings();
 $('newsStatus').textContent=phoneSettingsDirty?'Feed was not saved. Check settings status.':'Feed saved in cloud; phone delivery awaits sync.';
};
function bedtimePlan(wake,goal) {
 const norm=n=>((n%1440)+1440)%1440;
 const display=n=>`${String(Math.floor(norm(n)/60)).padStart(2,'0')}:${String(norm(n)%60).padStart(2,'0')}`;
 return {suggested:display(wake-goal),cycles:[6,5,4,3].map(n=>({cycles:n,time:display(wake-n*90-15)}))};
}
function renderBedtime() {
 if(!phoneSettingsVersion){$('bedtimeSummary').textContent='Sync an updated phone first. No phone settings have been guessed.';return;}
 const [h,m]=$('bedtimeWake').value.split(':').map(Number);if(!Number.isInteger(h)||!Number.isInteger(m))return;
 const goal=phoneSettings.sleepGoalHours*60+phoneSettings.sleepGoalMinutes;
 const plan=bedtimePlan(h*60+m,goal);
 $('bedtimeSummary').innerHTML=`<p>Phone bedtime ${String(phoneSettings.bedtimeHour).padStart(2,'0')}:${String(phoneSettings.bedtimeMinute).padStart(2,'0')} · ${phoneSettings.bedtimeEnabled?'enabled':'disabled'} · reminder ${phoneSettings.bedtimeReminderMinutes} minutes before</p><p>Sleep goal ${phoneSettings.sleepGoalHours}h ${phoneSettings.sleepGoalMinutes}m. Suggested bedtime for your chosen wake time: <strong>${plan.suggested}</strong></p><p>90-minute cycle estimates (15 minutes to fall asleep): ${plan.cycles.map(row=>row.time+' ('+row.cycles+' cycles)').join(' · ')}. Estimates, not medical advice.</p>`;
 const items=phoneSettings.bedtimeChecklist.split('\n').map(s=>s.trim()).filter(Boolean);
 $('bedtimeChecklist').innerHTML=items.map((item,i)=>`<label class="switch-field"><span>${escapeHtml(item)}</span><input class="switch" type="checkbox" aria-label="${escapeAttr(item)}"></label>`).join('');
}
$('bedtimeWake').onchange=renderBedtime;
$('bedtimeSettings').onclick=()=>document.querySelector('[data-tab=settings]').click();
document.querySelector('[data-tab=news]').addEventListener('click',()=>loadNewsFeeds().catch(e=>$('newsStatus').textContent=e.message));
document.querySelector('[data-tab=bedtime]').addEventListener('click',renderBedtime);
let todaySelectedCity=null;
function renderTodayAlarms() {
 const alarms=state.alarms.filter(row=>!row.deletedAt && row.payload.isEnabled).sort((a,b)=>a.payload.hour*60+a.payload.minute-b.payload.hour*60-b.payload.minute);
 $('todayAlarms').innerHTML='<h3>Enabled cloud alarms</h3>'+(alarms.length?alarms.map(row=>`<p><strong>${String(row.payload.hour).padStart(2,'0')}:${String(row.payload.minute).padStart(2,'0')}</strong> ${escapeHtml(row.payload.label||'Alarm')}</p>`).join(''):'<p>No enabled cloud alarms.</p>');
}
$('todaySearch').onclick=async()=>{
 const button=$('todaySearch');button.disabled=true;
 try {
  const data=await api('/api/today/cities?name='+encodeURIComponent($('todayCity').value));
  $('todayCities').innerHTML=data.results.map((city,i)=>`<button type="button" class="secondary" data-city-choice="${i}">${escapeHtml(city.name)}, ${escapeHtml(city.admin1||'')} ${escapeHtml(city.country||'')}</button>`).join('');
  $('todayStatus').textContent=data.results.length?'Choose the city to read its weather.':'No cities found.';
  $('todayCities').querySelectorAll('[data-city-choice]').forEach(button=>button.onclick=()=>{todaySelectedCity=data.results[Number(button.dataset.cityChoice)];refreshTodayWeather();});
 } catch(e){$('todayStatus').textContent=e.message;}
 finally{button.disabled=false;}
};
async function refreshTodayWeather() {
 if(!todaySelectedCity){$('todayStatus').textContent='Search and select a city first.';return;}
 const button=$('todayWeatherRefresh');button.disabled=true;
 try {
  const city=todaySelectedCity;
  const data=await api(`/api/today/weather?latitude=${encodeURIComponent(city.latitude)}&longitude=${encodeURIComponent(city.longitude)}&unit=${encodeURIComponent(phoneSettings.temperatureUnit)}`);
  const current=data.current,units=data.current_units,daily=data.daily;
  if(!current||!daily)throw Error('incomplete_forecast');
  $('todayStatus').textContent=`${city.name}: ${data.stale?'cached forecast, refresh failed':'forecast loaded'} at ${new Date(data.fetchedAtMillis).toLocaleString()}.`;
  $('todayWeather').innerHTML=`<div class="card"><h3>${escapeHtml(city.name)}</h3><p>${escapeHtml(String(current.temperature_2m))} ${escapeHtml(units.temperature_2m)} · feels like ${escapeHtml(String(current.apparent_temperature))} · humidity ${escapeHtml(String(current.relative_humidity_2m))}%</p><p>Wind ${escapeHtml(String(current.wind_speed_10m))} ${escapeHtml(units.wind_speed_10m)} · weather code ${escapeHtml(String(current.weather_code))}</p></div>`+daily.time.map((day,i)=>`<div class="card"><h3>${escapeHtml(day)}</h3><p>${escapeHtml(String(daily.temperature_2m_min[i]))} to ${escapeHtml(String(daily.temperature_2m_max[i]))} ${escapeHtml(units.temperature_2m)} · rain ${escapeHtml(String(daily.precipitation_probability_max[i]))}% · UV ${escapeHtml(String(daily.uv_index_max[i]))}</p><p>Sunrise ${escapeHtml(daily.sunrise[i])}<br>Sunset ${escapeHtml(daily.sunset[i])}</p></div>`).join('')+(data.hourly?.time ? '<div class="card"><h3>Hourly forecast</h3>'+data.hourly.time.map((time,i)=>({time,i})).filter(row=>row.time>=current.time).slice(0,12).map(({time,i})=>`<p>${escapeHtml(time)} · ${escapeHtml(String(data.hourly.temperature_2m[i]))} ${escapeHtml(units.temperature_2m)} · rain ${escapeHtml(String(data.hourly.precipitation_probability[i]))}%</p>`).join('')+'</div>' : '')+(data.airQuality?.current ? '<div class="card"><h3>Air quality and pollen</h3>'+Object.entries(data.airQuality.current).filter(([key,value])=>key!=='interval' && value!==null).map(([key,value])=>`<p>${escapeHtml(key.replaceAll('_',' '))}: ${escapeHtml(String(value))} ${escapeHtml(data.airQuality.current_units?.[key]||'')}</p>`).join('')+'</div>' : '<p>Air quality unavailable for this refresh.</p>')+'<p><a href="https://open-meteo.com/ target="_blank" rel="noopener noreferrer">Weather data by Open-Meteo</a>. Forecast timezone: '+escapeHtml(data.timezone)+'.</p>';
 } catch(e){$('todayStatus').textContent='Could not refresh: '+e.message+'. Previous forecast, if any, is unchanged.';}
 finally{button.disabled=false;}
}
$('todayWeatherRefresh').onclick=refreshTodayWeather;
document.querySelector('[data-tab=today]').addEventListener('click',renderTodayAlarms);
