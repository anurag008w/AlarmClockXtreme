let newsFeeds=[];
async function loadNewsFeeds() {
 const data=await api('/api/news/feeds');newsFeeds=data.feeds;
 const match=newsFeeds.find(feed=>feed.url===phoneSettings.newsFeedUrl);
 $('newsFeed').innerHTML=newsFeeds.map(feed=>`<option value="${escapeAttr(feed.id)}">${escapeHtml(feed.label)}</option>`).join('');
 $('newsFeed').value=match?.id||'bbc';
 $('newsStatus').textContent=match ? 'Saved phone feed selected.' : 'Phone has a custom or unsynced feed. BBC is selected for reading only, not saved.';
}
async function refreshNews() {
 const button=$('newsRefresh');button.disabled=true;
 try {
  if(!newsFeeds.length)await loadNewsFeeds();
  const data=await api('/api/news?feed='+encodeURIComponent($('newsFeed').value));
  $('newsStatus').textContent=`${data.stale?'Cached news, refresh failed.':'Feed loaded.'} Fetched ${new Date(data.fetchedAtMillis).toLocaleString()}`;
  $('newsList').innerHTML=data.items.length ? data.items.map(item=>`<article class="card"><h3><a href="${escapeAttr(item.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(item.title)}</a></h3><p>${escapeHtml(item.summary)}</p><small class="muted">${escapeHtml(item.published)}</small></article>`).join('') : '<p>No feed entries.</p>';
 } catch(error){$('newsStatus').textContent='Could not refresh: '+error.message+'. Any previous entries below are unchanged.';}
 finally{button.disabled=false;}
}
$('newsRefresh').onclick=refreshNews;
$('newsSave').onclick=async()=>{
 if(!phoneSettingsVersion||phoneSettingsDirty){$('newsStatus').textContent='Sync an updated phone and save or reload existing settings first.';return;}
 const feed=newsFeeds.find(feed=>feed.id===$('newsFeed').value);if(!feed)return;
 phoneSettings.newsFeedUrl=feed.url;phoneSettingsDirty=true;await savePhoneSettings();
 $('newsStatus').textContent=phoneSettingsDirty?'Feed was not saved. Check settings status.':'Feed saved in cloud; phone delivery awaits sync.';
};
function bedtimePlan(wake,goal) {
 const norm=n=>((n%1440)+1440)%1440;
 const display=n=>`${String(Math.floor(norm(n)/60)).padStart(2,'0')}:${String(norm(n)%60).padStart(2,'0')}`;
 return {suggested:display(wake-goal),cycles:[6,5,4,3].map(n=>({cycles:n,time:display(wake-n*90-15)}))};
}
function renderBedtime() {
 if(!phoneSettingsVersion){$('bedtimeSummary').textContent='Sync an updated phone first. No phone settings have been guessed.';return;}
 const [h,m]=$('bedtimeWake').value.split(':').map(Number);if(!Number.isInteger(h)||!Number.isInteger(m))return;
 const goal=phoneSettings.sleepGoalHours*60+phoneSettings.sleepGoalMinutes;
 const plan=bedtimePlan(h*60+m,goal);
 $('bedtimeSummary').innerHTML=`<p>Phone bedtime ${String(phoneSettings.bedtimeHour).padStart(2,'0')}:${String(phoneSettings.bedtimeMinute).padStart(2,'0')} · ${phoneSettings.bedtimeEnabled?'enabled':'disabled'} · reminder ${phoneSettings.bedtimeReminderMinutes} minutes before</p><p>Sleep goal ${phoneSettings.sleepGoalHours}h ${phoneSettings.sleepGoalMinutes}m. Suggested bedtime for your chosen wake time: <strong>${plan.suggested}</strong></p><p>90-minute cycle estimates (15 minutes to fall asleep): ${plan.cycles.map(row=>row.time+' ('+row.cycles+' cycles)').join(' · ')}. Estimates, not medical advice.</p>`;
 const items=phoneSettings.bedtimeChecklist.split('\n').map(s=>s.trim()).filter(Boolean);
 $('bedtimeChecklist').innerHTML=items.map((item,i)=>`<label class="switch-field"><span>${escapeHtml(item)}</span><input class="switch" type="checkbox" aria-label="${escapeAttr(item)}"></label>`).join('');
}
$('bedtimeWake').onchange=renderBedtime;
$('bedtimeSettings').onclick=()=>document.querySelector('[data-tab=settings]').click();
document.querySelector('[data-tab=news]').addEventListener('click',()=>loadNewsFeeds().catch(e=>$('newsStatus').textContent=e.message));
document.querySelector('[data-tab=bedtime]').addEventListener('click',renderBedtime);
