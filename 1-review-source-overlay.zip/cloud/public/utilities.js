let utilityBusy = false;
async function refreshPhoneTimers() {
  const device=$('utilityDevice').value;
  if(!device) { $('phoneUtilityStatus').textContent='Choose a phone first.';return; }
  const data=await api('/api/utilities/'+encodeURIComponent(device));
  const snapshot=data.items.find(row=>row.id==='snapshot-'+device);
  const commands=data.items.filter(row=>row.command);
  $('phoneUtilityStatus').textContent=commands.slice(-5).map(row=>`${row.command.action}: ${row.status}${row.result ? ' ('+row.result+')' : ''}`).join(' · ') || 'No commands yet.';
  const payload=snapshot?.payload;
  const age=payload ? Math.max(0,Math.floor((data.serverNowMillis-payload.observedServerMillis)/1000)) : null;
  $('phoneTimerList').innerHTML=payload ? `<p>Phone snapshot ${age}s old. Countdown is approximate, not proof of ringing.</p>`+payload.timers.map(timer=>`<div class="card"><strong>${escapeHtml(timer.label||'Timer '+timer.id)}</strong><p>${escapeHtml(timer.state)} · ${Math.ceil(timer.remainingMillis/1000)}s at snapshot</p>${['pause','resume','stop'].map(action=>`<button class="btn secondary" type="button" data-native-timer="${timer.id}" data-action="${action}">${action}</button>`).join('')}</div>`).join('') : 'No phone snapshot. Sync an updated Android app first.';
  $('phoneTimerList').querySelectorAll('[data-native-timer]').forEach(button=>button.onclick=()=>sendPhoneTimer(button.dataset.action,{timerId:Number(button.dataset.nativeTimer)}));
}
async function sendPhoneTimer(action,payload) {
  if(utilityBusy)return;
  const device=$('utilityDevice').value;if(!device)return;
  const commandId=crypto.randomUUID().replaceAll('-','');utilityBusy=true;
  try {
    const row=await api('/api/utilities/commands',{method:'POST',body:JSON.stringify({deviceId:device,commandId,kind:'timer',action,payload})});
    $('phoneUtilityStatus').textContent=`${row.status}: command ${commandId}. Not proof the phone applied it.`;
    await refreshPhoneTimers();
  } catch(error) { $('phoneUtilityStatus').textContent=`${error.message}. Command ID ${commandId}: check phone status before retrying.`; }
  finally {utilityBusy=false;}
}
$('loadUtilityDevices').onclick=async()=>{
 try {const data=await api('/api/utilities/devices');$('utilityDevice').innerHTML='<option value="">Choose phone</option>'+data.devices.filter(d=>d.platform==='android').map(d=>`<option value="${escapeAttr(d.id)}">${escapeHtml(d.id)} (${escapeHtml(d.appVersion||'unknown version')})</option>`).join('');}
 catch(error){$('phoneUtilityStatus').textContent=error.message;}
};
$('utilityDevice').onchange=()=>refreshPhoneTimers().catch(error=>$('phoneUtilityStatus').textContent=error.message);
$('refreshPhoneTimers').onclick=()=>refreshPhoneTimers().catch(error=>$('phoneUtilityStatus').textContent=error.message);
$('startPhoneTimer').onclick=()=>{
 const seconds=Number($('phoneTimerSeconds').value);
 if(!Number.isInteger(seconds)||seconds<1||seconds>86400){$('phoneUtilityStatus').textContent='Seconds must be 1..86400';return;}
 sendPhoneTimer('start',{seconds,label:$('phoneTimerLabel').value});
};
