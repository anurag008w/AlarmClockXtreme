package com.sysadmindoc.alarmclock.data.cloud
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.sysadmindoc.alarmclock.ui.timer.TimerStore
import com.sysadmindoc.alarmclock.ui.timer.TimerState
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[30],application=Application::class)
class CloudUtilityControllerTest {
 @Test fun timerCommandsUsePhoneClockAndAreNotDuplicated() {
  val context=ApplicationProvider.getApplicationContext<Context>()
  context.getSharedPreferences("cloud_utility_journal",Context.MODE_PRIVATE).edit().clear().commit()
  val store=TimerStore(context);store.replace(emptyList())
  val controller=CloudUtilityController(context)
  val start=CloudUtilityCommand("phone","start-123","timer","start",mapOf("seconds" to 60.0,"label" to "Test"))
  assertEquals("applied",controller.apply(start).first)
  assertEquals("applied",controller.apply(start).first)
  assertEquals(1,store.loadRecords().size)
  val id=store.loadRecords().single().id
  assertEquals("applied",controller.apply(CloudUtilityCommand("phone","pause-123","timer","pause",mapOf("timerId" to id))).first)
  assertEquals(TimerState.PAUSED,store.loadRecords().single().state)
  assertEquals("applied",controller.apply(CloudUtilityCommand("phone","resume-123","timer","resume",mapOf("timerId" to id))).first)
  assertEquals(TimerState.RUNNING,store.loadRecords().single().state)
  assertEquals("applied",controller.apply(CloudUtilityCommand("phone","stop-123","timer","stop",mapOf("timerId" to id))).first)
  assertTrue(store.loadRecords().isEmpty())
 }
 @Test fun interruptedClaimDoesNotReplayNativeEffect() {
  val context=ApplicationProvider.getApplicationContext<Context>()
  context.getSharedPreferences("cloud_utility_journal",Context.MODE_PRIVATE).edit().putString("crashed-123","claimed").commit()
  val result=CloudUtilityController(context).apply(CloudUtilityCommand("phone","crashed-123","timer","start",mapOf("seconds" to 60)))
  assertEquals("rejected",result.first)
  assertEquals("interrupted_check_phone",result.second)
 }
}
